# -*- coding:utf-8 -*-

from datetime import datetime, date, timedelta
from dateutil import relativedelta
from num2words import num2words

import locale
import logging

from odoo import models, fields, api


class HrContract(models.Model):
    _inherit = 'hr.contract'

    bono_asistencia_mensual = fields.Float(string='Bono Asistencia Mensual %')
    type_contract = fields.Selection([('TD','Tiempo determinado'),
                                    ('TI','Tiempo Indeterminado'),],string='Tipo de contrato', required=True)

class ContratoDeterminadoIndeterminado(models.AbstractModel):
    _name = 'report.reportes.hr_employee_determ_undeter_report_id'

    @api.model
    def _get_report_values(self, docids, data=None):
        type_list = []
        error = ''
        model = 'hr.employee'
        # for d in docids:
        #     # determ contract
        contract = self.env["hr.contract"].search([
            ('employee_id', '=', docids),
            ('state', 'in', ['open', 'pending']),
            ('active', '=', True)
        ])
        #     employee_name = self.env['hr.employee'].browse(d).name
        #     if contract:
        #         valid_fields = self.validate_responsibilities(contract)
        #         if valid_fields['responsibilities'] == 0:
        #             error = "No se puede imprimir este contrato por que no cuenta con responsabilidades asignadas"
        #         # elif valid_fields['modifications'] == 0:
        #         #     error = "No se puede imprimir este contrato por que no cuenta con modificaciones asignadas"
        #         else:
        #             if contract.type_contract:
        #                 if contract.type_contract == "TD" or contract.type_contract == "TI":
        #                     type_list.append(contract.type_contract)
        #                 else:
        #                     error = "El empleado '%s' tiene un tipo de contrato no es valido." % employee_name
        #             else:
        #                 error = "El empleado '%s' no tiene configurado un tipo de contrato." % employee_name
        #     else:
        #         error = "El empleado '%s' no cuenta con un contrato vigente." % employee_name
        # construct data
        type_list.append(contract.type_contract)
        docs = self.env['hr.employee'].search([('id','in',docids)])
        # print("#################### TYPE LIST >>>>>>>>>>>>>>>>>> ", type_list)
        # if error:
        #     raise ValidationError(error)
        # else:
        docargs = {
            'doc_ids': docids,
            'doc_model': model,
            'docs': docs,
            'type_contract': type_list,
        }
        return docargs