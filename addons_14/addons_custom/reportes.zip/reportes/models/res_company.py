# -*- coding:utf-8 -*-

from odoo import models, fields, api


class ResCompany(models.Model):
    _inherit = 'res.company'

    apoderado = fields.Char(string='Apoderado Legal')
    attorney=fields.Many2one('hr.employee', string="Apoderado Legal")
    rh=fields.Many2one('hr.employee', string="Jefe de Recursos Humanos")
    do=fields.Many2one('hr.employee', string="Gerente de desarrollo Organizacional")
    dg=fields.Many2one('hr.employee', string="Director General")
    arh=fields.Many2one('hr.employee', string="Analista de Recursos Humanos")
    accounting=fields.Many2one('hr.employee', string='Contabilidad')
    systems=fields.Many2one('hr.employee', string='Sistemas')
    payroll=fields.Many2one('hr.employee', string=u'Nómina')
    assets=fields.Many2one('hr.employee', string='Seguros y activos fijos')
    buys=fields.Many2one('hr.employee', string='Compras')
    instrument_constitutive=fields.Integer(string="Instrumento Constitutivo")
    volume_constitutive=fields.Integer(string="Volumen Constitutivo")
    instrument_power=fields.Integer(string="Instrumento Poder")
    volume_power=fields.Integer(string="Volumen Poder")
    location_key=fields.Char(string=u"Clave de Ubicación")
