# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
#from datetime import datetime

class AccountMoveLineCustom(models.Model):
    _inherit = 'account.move.line'

    #Saber si el apunte contable está asociado a un registro de conciliación
    # reconciliation_bank_id = fields.Many2one(
    #     'reconciliation.bank', string='Conciliación Bancaria')
    #Saber si se seleccionó en el wizard para conciliaciones
    # checked_in_wizard = fields.Boolean(string='Seleccionado')

    saldo_inicial = fields.Monetary(string='Saldo inicial')
    saldo_final = fields.Monetary(string='Saldo final')

    def open_print_auxiliar_contable(self):
        records = [r.id for r in self]
        return {
            'name'          :   'Print Auxiliar Contable',
            'type'          :   'ir.actions.act_window',
            'view_type'     :   'form',
            'view_mode'     :   'form',
            'target'        :   'new',
            'context'        :   {'records':records},
            'res_model'     :   'auxiliar.contable.report.download',
        }
