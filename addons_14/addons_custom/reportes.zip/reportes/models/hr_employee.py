# -*- coding:utf-8 -*-

from datetime import datetime, date, timedelta
from dateutil import relativedelta
from num2words import num2words

import locale
import logging

from odoo import models, fields, api


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    vat = fields.Char(string="RFC")
    curp = fields.Char(string="Curp")
    specialty = fields.Char(string=u'Especialidad')
    beneficiary = fields.Char(string=u'Beneficiario de Seguro de Vida')


    def get_do(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return data.do.name

    def instrument_constitutive(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return data.instrument_constitutive

    def volume_constitutive(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return data.volume_constitutive

    def instrument_power(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return num2words(data.instrument_power, lang='es')

    def volume_power(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return num2words(data.volume_power, lang='es')

    def get_instrument_power(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return data.instrument_power

    def get_volume_power(self):
        data = self.env['res.company'].search([('id','=',self.company_id.id)])
        return data.volume_power

    def salary_day(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        total = contract.wage/30
        total_day = "%.2f" % total
        return total_day

    def salary_day_words(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        total = contract.wage/30
        total_day = "%.2f" % total
        return num2words(total_day, lang='es').split(' punto ')[0]

    def salary_day_decimal(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        total = contract.wage/30
        total_day = "%.2f" % total
        partes = str(total_day).split('.')
        decimal = partes[1]+'/100'
        return decimal

    def bonusambos(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        percentasis = contract.bono_asistencia_mensual/100
        asistencia = percentasis*contract.wage
        total = "%.2f" % asistencia
        return total

    def bonusambos_words(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        percentasis = contract.bono_asistencia_mensual/100
        asistencia = percentasis*contract.wage
        total = "%.2f" % asistencia
        return num2words(total, lang='es').split(' punto ')[0]

    def bonusambos_deci(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        percentasis = contract.bono_asistencia_mensual/100
        asistencia = percentasis*contract.wage
        total = "%.2f" % asistencia
        notoal = str(total).split('.')
        decimal = notoal[1]+'/100'
        return decimal

    def _get_age(self):
        today = date.today()
        days = abs((today - self.birthday).days)
        years = int(days / 365)
        return years

    def horary(self):
        hr=self.resource_calendar_id.id
        calendar=self.env['resource.calendar'].search([('id','=',hr)])
        attendance=self.env['resource.calendar.attendance'].search([('calendar_id','=',calendar.id)],order='dayofweek asc')
        day = None
        data = []
        start_date = ''
        end_date = ''
        for x in attendance:
            if x.dayofweek != day:
                start_date = (str(x.hour_from)).replace('.',':')
            elif x.dayofweek == day:
                end_date = (str(x.hour_to)).replace('.',':')
            data.append([int(x.dayofweek),start_date,end_date])
            day = x.dayofweek
        min_date = self.my_min(data)
        max_date = self.my_max(data)
        start_day = min_date[0]
        end_day = max_date[0]
        if start_day == 0:
            start_day = 'Lunes'
        if start_day == 1:
            start_day = 'Martes'
        if start_day == 2:
            start_day = 'Miércoles'
        if start_day == 3:
            start_day = 'Jueves'
        if start_day == 4:
            start_day = 'Viernes'
        if start_day == 5:
            start_day = 'Sábado'
        if start_day == 6:
            start_day = 'Domingo'
        if end_day == 0:
            end_day = 'Lunes'
        if end_day == 1:
            end_day = 'Martes'
        if end_day == 2:
            end_day = 'Miércoles'
        if end_day == 3:
            end_day = 'Jueves'
        if end_day == 4:
            end_day = 'Viernes'
        if end_day == 5:
            end_day = 'Sábado'
        if end_day == 6:
            end_day = 'Domingo'
        return ' las '+ min_date[1]+'0 horas' +' a '+ max_date[2]+'0 horas' +' del día '+ start_day+' al '+end_day+' '

    def get_date_contract_start(self):
        contract = self.env['hr.contract'].search([('employee_id','=',self.id),('state','=','open')],limit=1)
        if contract:
            date_start = self.get_format_day(contract.date_start)
            return date_start

    def get_format_date(self):
        meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
        currd = date.today()
        return str(currd.day) + ' de ' +meses[currd.month - 1]+ ' de ' + str(currd.year)

    def salary(self):
        contract = self.env['hr.contract'].search(
            [('employee_id', '=', self.id)], limit=1)
        total = "%.2f" % contract.wage
        return total

    def get_format_day(self, date):
        meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
        return str(date.day) + ' de ' +meses[date.month - 1]+ ' de ' + str(date.year)