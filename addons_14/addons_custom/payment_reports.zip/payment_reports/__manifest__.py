#-*- coding: utf-8 -*-
{
    'name': "Reportes",
    'summary': """
        Módulo complementario de Agrovizion para reportes
    """,
    'description': """
        Módulo para extender la funcionalidad de empleados
    """,
    'author': "Gabriel Lopez",
    'website': "",
    'category': 'hr',
    'version': '0.1',
    'depends': [
        'account', 
        'account_accountant',
        'agv_cost_center',
    ],
    'data': [
        'reports/report_payment_policy.xml',
        'reports/report_payment_receipt.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}

