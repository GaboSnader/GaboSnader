# -*- coding: utf-8 -*-
from odoo import models, fields, api


class AccountPayment(models.Model):
    _inherit = "account.payment"

    def _get_invoice(self,inv):
        name=self.move_id
        company_id=self.company_id.id
        
        # mv_ids = [name.id]
        mv_ids = []
        for mv in self.reconciled_invoice_ids:
            mv_ids.append(mv.id)
            for mid in self.env['account.move'].search([('ref','=',mv.name),('move_type','=','entry')]):
                if mid.amount_total_signed == self.amount or mid.amount_total_signed == name.amount_total:
                    mv_ids.append(mid.id)
        lines = self.env['account.move.line'].search([('move_id','in',mv_ids)])

        return lines


    def _sum_account(self,inv):
        name = self.move_id
        name_payment=self.name
        company_id=self.company_id.id
        # print(name)
        #print(name_payment)

        self._cr.execute("""      
                    select sum(ml.debit) as total_debit,sum(ml.credit) as total_credit
                    from  account_move_line  ml 
                    inner join account_move  m on m.id=ml.move_id
                    where m.company_id='%s' and (m.name='%s' or m.ref='%s')
                              """ % (company_id,name,name))

        sum = self.env.cr.dictfetchall()
        # print(sum)

        return sum





