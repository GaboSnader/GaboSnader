from odoo import models, fields


class Partner(models.Model):
    _inherit = 'res.partner'

    document_ids = fields.One2many(
        'res.partner.document',
        inverse_name='partner_id',
        string='Documents'
    )
