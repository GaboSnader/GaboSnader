from odoo import models, fields


class DocumentType(models.Model):
    _name = "document.type"
    _description = "Document Type"

    name = fields.Char(required=True)
    description = fields.Text(string='Document Type Description')

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         'Name is already assigned.')
    ]
