from . import document_type
from . import res_partner_document
from . import res_partner
