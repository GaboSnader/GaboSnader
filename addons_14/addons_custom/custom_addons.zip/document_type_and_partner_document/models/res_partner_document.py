from datetime import datetime, date
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class PartnerDocument(models.Model):
    _name = "res.partner.document"
    _description = "Partner Document"

    partner_id = fields.Many2one(
        'res.partner',
        required=True,
        ondelete='restrict',
        readonly=True
    )
    document_type_id = fields.Many2one(
        'document.type',
        required=True
    )

    expiration_date = fields.Date(required=True)
    attachment = fields.Many2one('ir.attachment', readonly=True)
    notes = fields.Text()
    file_attachment = fields.Binary(store=False)
    document_active = fields.Boolean(default=False)

    validate = fields.Boolean(default=False)
    validate_date = fields.Date()
    validate_user_id = fields.Many2one('res.users')

    @api.constrains('expiration_date')
    def check_expiration_date(self):
        if self.expiration_date <= date.today():
            raise ValidationError(_('Expiration date prior to current.'))
        # raise ValidationError('Fecha de expiracion anterior a al actual.')

    @api.model
    def create(self, vals):
        if not vals['file_attachment']:
            raise UserError(_('Required file.'))
        attachment = {
            'name': self.generate_attachment_name(vals),
            'datas': vals['file_attachment'],
        }
        attachment = self.env['ir.attachment'].sudo().create(attachment)
        vals['attachment'] = attachment.id
        return super(PartnerDocument, self).create(vals)

    def write(self, vals):
        if 'validate' in vals:
            if self.expiration_date <= date.today():
                raise ValidationError(_('Expiration date prior to current.'))
            vals['validate_date'] = date.today()
            vals['validate_user_id'] = self.env.user.id

            document_active = self.search([
                ('partner_id', '=', self.partner_id.id),
                ('document_type_id', '=', self.document_type_id.id),
                ('document_active', '=', True)
            ])

            if not document_active:
                vals['document_active'] = True

        elif vals.get('document_active', False):
            if self.expiration_date <= date.today():
                raise ValidationError(_('Expiration date prior to current.'))

            document_active = self.search([
                ('partner_id', '=', self.partner_id.id),
                ('document_type_id', '=', self.document_type_id.id),
                ('document_active', '=', True)
            ])

            if document_active:
                raise ValidationError(_('Active document already exists.'))
        return super(PartnerDocument, self).write(vals)

    @api.model
    def generate_attachment_name(self, vals):
        partner = self.env['res.partner'].sudo()
        partner_result = partner.search_read(
            [('id', '=', vals['partner_id'])],
            ['name']
        )
        partner_name = partner_result[0]['name']
        attachment_name = partner_name + \
            vals['expiration_date'] + \
            str(datetime.now())
        attachment_name = attachment_name \
            .replace('-', '') \
            .replace(' ', '') \
            .replace(':', '') \
            .replace('.', '')
        return attachment_name

    @api.model
    def update_state(self):
        self.search([
            ('document_active', '=', True),
            ('expiration_date', '<', fields.Date.to_string(date.today())),
        ]).write({
            'document_active': False
        })
        return True
