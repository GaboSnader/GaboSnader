{
    'name': "document_type_and_partner_document",

    'summary': """ Add Document to Partner""",

    'description': """
    Add Document line to partner and date validation.
    """,

    'author': "Edgar Inzunza",

    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/document_data.xml',
        'views/res_partner.xml',
        'views/document_type.xml',
    ],

}
