from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    contract_count = fields.Integer(
        string='No. Contract',
        compute='_compute_contract_count',
    )

    contract_ids = fields.One2many(
        'agv.contract',
        inverse_name='partner_id',
        string="Contracts",
    )

    def _compute_contract_count(self):
        for partner in self:
            partner.contract_count = len(partner.contract_ids)

    # def action_show_contract(self):

    #     self.ensure_one()

    #     res = self._get_act_window_contract_xml()

    #     res.update(
    #         context=dict(
    #             self.env.context,
    #             search_default_partner_id=self.id,
    #             default_partner_id=self.id,
    #             default_pricelist_id=self.property_product_pricelist.id,
    #         ),
    #     )

    #     return res

    # def _get_act_window_contract_xml(self):
    #     return self.env['ir.actions.act_window'].for_xml_id(
    #         'contract', 'action_customer_contract'
    #     )
