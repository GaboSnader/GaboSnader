from odoo import models, fields, api


class ConfirmationWizard(models.TransientModel):
    _name = "agv.contract.wizard"
    _description = "Contract Wizard"

    def _default_message(self):
        return self._context.get('message')

    message = fields.Char(
        default=_default_message,
        readonly=True
    )

    justification = fields.Text(required=True,)

    def ok(self):
        self.ensure_one()
        defs = self._context.get('def')
        model = self._context.get('model')
        model_id = self._context.get('model_id')
        document = self.env[model].browse(model_id)
        method = getattr(type(document), defs)
        method(document, self.justification)
        return {'type': 'ir.actions.act_window_close'}
