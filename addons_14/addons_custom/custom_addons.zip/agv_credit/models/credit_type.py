from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class CreditType(models.Model):
    _name = 'credit.type'
    _description = 'Credit Type'

    name = fields.Char(
        string='Credit Type Name',
        required=True
    )

    folio = fields.Char(readonly=True)

    description = fields.Text(string='Credit Description')

    radical_credit = fields.Boolean(
        help='Check this to use Radical'
    )

    radical_id = fields.Integer()

    unalterable_date = fields.Boolean(
        default=True,
        help='Check this if date end unalterable.'
    )

    revolving_credit = fields.Boolean(
        help='Check this if the credit is revolving.'
    )

    per_hectare = fields.Boolean(
        default=True
    )

    document_ids = fields.One2many(
        'credit.document.line',
        inverse_name='credit_type_id'
    )

    account_id = fields.Many2one(
        'account.account',
        company_dependent=True,
        domain="[('internal_type', '=', 'receivable'), ('deprecated', '=', False), ('company_id', '=', current_company_id)]",
        required=True
    )

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         'Name is already assigned.')
    ]

    def _get_folio(self):
        self.ensure_one()
        if not self.id:
            return ''
        return str(self.id).zfill(5)

    @api.model
    def create(self, vals):
        res = super(CreditType, self).create(vals)
        res.folio = res._get_folio()
        return res

    # TODO: Generate Test constrains
    # @api.constrains('radical_id')
    # def validate_radical_id(self):
    #     for record in self:
    #         credit_type_count = self.sudo() \
    #             .search_count([('radical_id', '=', record.radical_id)])
    #         if credit_type_count > 1:
    #             raise ValidationError(
    #                 _('Credit Type with this Radical Id (%s) already exists.') %
    #                 record.radical_id
    #             )


class ContractTypeDocument(models.Model):
    _name = 'credit.document.line'
    _description = 'Credit Document Line'

    credit_type_id = fields.Many2one('credit.type', required=True)
    document_type_id = fields.Many2one('document.type', required=True)

    mandatory_company_partner = fields.Boolean()
    mandatory_no_company_partner = fields.Boolean(default=True)
