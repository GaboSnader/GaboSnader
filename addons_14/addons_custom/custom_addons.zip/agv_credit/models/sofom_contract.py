import ast
from datetime import date
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SOFOMContractMovement(models.Model):
    _name = 'sofom.contract.movement'
    _description = "Manual Credit Movement"

    state = fields.Selection([
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='done', copy=False, readonly=True)

    sofom_contract_id = fields.Many2one(
        'sofom.contract',
        string='Sofom Contract',
        ondelete='restrict',
        readonly=True,
        required=True,
    )

    movement_type = fields.Selection([
        ('charge', 'Charge'),
        ('payment', 'Payment'),
    ], required=True)

    description = fields.Char(required=True)

    amount_charge = fields.Monetary()
    amount_payment = fields.Monetary()

    currency_id = fields.Many2one(
        'res.currency',
        related='sofom_contract_id.currency_id'
    )

    @api.onchange('movement_type')
    def _onchange_movement_type(self):
        self.update({
            'amount_charge': 0.00,
            'amount_payment': 0.00,
        })

    @api.constrains('amount_charge', 'amount_payment', 'movement_type')
    def _constrains_amounts(self):
        for line in self:
            if (line.amount_charge - line.amount_payment == 0.00
                    and line.amount_charge * line.amount_payment == 0.00):
                raise ValidationError('Error en montos al agregar la linea.')
            if (line.amount_charge < 0.00 or line.amount_payment < 0.00):
                raise ValidationError('Error en montos al agregar la linea.')
            if (line.movement_type == 'charge' and
                    ((line.amount_charge == 0.00) or
                     (line.amount_payment != 0.00))):
                raise ValidationError('Error en montos al agregar la linea.')
            if (line.movement_type == 'payment' and
                    ((line.amount_charge != 0.00) or
                     (line.amount_payment == 0.00))):
                raise ValidationError('Error en montos al agregar la linea.')


class SOFOMContract(models.Model):
    _name = 'sofom.contract'
    _description = "Agrofinanciaera Contract"
    _order = 'name asc'
    _inherit = [
        'mail.thread',
        'mail.activity.mixin',
    ]

    name = fields.Char(
        readonly=True,
    )

    partner_id = fields.Many2one(
        'res.partner',
        string="Customer",
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
    )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('active', 'Active'),
        ('blocked', 'Blocked'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft', copy=False, readonly=True)

    sale_count = fields.Integer(compute="_compute_sale_count")
    invoice_count = fields.Integer(compute="_compute_invoice_count")
    movement_count = fields.Integer(compute="_compute_movement_count")

    date_end = fields.Date(
        readonly=True,
        required=True,
        states={'draft': [('readonly', False)]}
    )

    unalterable_date_end = fields.Boolean(
        related='credit_type_id.unalterable_date',
        store=True
    )

    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.user.company_id,
        readonly=True,
    )

    warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Warehouse',
        readonly=True,
        required=True,
        states={'draft': [('readonly', False)]}
    )

    contract_type_id = fields.Many2one(
        'contract.type',
        string='Contract Type',
        ondelete='restrict',
        required=True,
        readonly=True,
        domain=[
            ('expiration_date', '>=', date.today()),
            ('radical_credit', '=', True)
        ],
        states={'draft': [('readonly', False)]}
    )

    currency_id = fields.Many2one(
        'res.currency',
        string="Currency",
        readonly=True,
        related='company_id.currency_id',
    )

    note = fields.Text(string="Notes")

    per_hectare = fields.Boolean(
        related='credit_type_id.per_hectare',
        store=True,
        readonly=True
    )

    hectares = fields.Float(
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    credit_amount = fields.Monetary(
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    credit_amount_available = fields.Monetary(
        string="Credit Available",
        compute='_compute_credit_amount',
        store=True
    )

    credit_amount_used = fields.Monetary(
        string="Credit Used",
        compute='_compute_credit_amount',
        store=True
    )

    amount_to_reconcile = fields.Monetary(
        string="Pending To Reconcile",
        compute='_compute_credit_amount',
        store=True
    )

    credit_amount_reserved = fields.Monetary(
        string="Credit Reserved",
        compute='_compute_amount_reserved',
        store=True
    )

    amount_pending_to_pay = fields.Monetary(
        string="Pending To Pay(Reembolsar)",
        compute='_compute_credit_amount',
        store=True
    )

    order_ids = fields.One2many(
        'sale.order',
        inverse_name='sofom_contract_id',
        string='Sale Orders'
    )

    invoice_ids = fields.One2many(
        'account.move',
        inverse_name='sofom_contract_id',
        string='Invoice'
    )

    movement_ids = fields.One2many(
        'sofom.contract.movement',
        inverse_name='sofom_contract_id',
        string='Movements'
    )

    revolving_credit = fields.Boolean(
        related='credit_type_id.revolving_credit',
        store=True,
        readonly=True
    )

    credit_type_id = fields.Many2one(
        'credit.type',
        related='contract_type_id.credit_type_id',
        store=True,
        readonly=True
    )

    radical_id = fields.Integer()

    @ api.constrains('hectares', 'per_hectare')
    def check_contract_hectare(self):
        for contract in self:
            if contract.per_hectare and contract.hectares <= 0.00:
                raise ValidationError(('Hectareas Necesarias'))

    def _compute_sale_count(self):
        for rec in self:
            rec.sale_count = len(rec.order_ids)

    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = len(rec.invoice_ids.filtered(
                lambda move: move.move_type == 'out_invoice'
            ))

    def _compute_movement_count(self):
        for rec in self:
            rec.movement_count = len(rec.movement_ids.filtered(
                lambda movement: movement.state == 'done'
            ))

    @api.depends('order_ids.order_line.invoice_lines.price_total', 'state')
    def _compute_amount_reserved(self):
        for contract in self:
            amount_reserved = 0.00
            orders = contract.order_ids.filtered(
                lambda order: (
                    order.state == 'sale' and
                    order.invoice_status != 'invoiced'
                )
            )
            for order in orders:
                amount_reserved += order.amount_total

                invoice_lines = order.order_line.invoice_lines.filtered(
                    lambda move_line: move_line.parent_state == 'posted'
                )

                if not invoice_lines:
                    continue

                amount_invoiced = sum(invoice_lines.mapped('price_total'))
                amount_reserved -= amount_invoiced
            contract.credit_amount_reserved = amount_reserved

    @api.depends('invoice_ids.amount_residual',
                 'invoice_ids.state',
                 'state',
                 'credit_amount_reserved')
    def _compute_credit_amount(self):
        for contract in self:
            if contract.state in ('draft'):
                contract.credit_amount_available = 0.00
                contract.credit_amount_used = 0.00
                contract.amount_to_reconcile = 0.00
                continue

            invoices = contract.invoice_ids \
                .filtered(lambda move: (
                    move.move_type == 'out_invoice' and
                    move.state == 'posted'
                ))

            used = 0.0
            reconcile_pending = 0.0
            for invoice in invoices:
                used += invoice.amount_total

                content = invoice._get_reconciled_info_JSON_values()
                move_ids = [move['move_id'] for move in content]

                refund_ids = self.env['account.move'].browse(move_ids) \
                    .filtered(lambda move: move.move_type == 'out_refund')

                for refund in invoice.refund_invoice_ids.filtered(lambda move: move.state == 'posted'):
                    if refund not in refund_ids:
                        reconcile_pending += refund.amount_total
                    else:
                        used -= refund.amount_total

            charge_movements = contract.movement_ids.filtered(
                lambda move: move.movement_type == 'charge'
            )

            used += sum(charge_movements.mapped('amount_charge'))

            contract.credit_amount_used = used
            contract.amount_to_reconcile = reconcile_pending

            contract.amount_pending_to_pay = sum(
                invoices.mapped('amount_residual')
            )

            if contract.revolving_credit:
                payment_movements = contract.movement_ids.filtered(
                    lambda move: move.movement_type == 'payment'
                )
                amount_payment = sum(
                    payment_movements.mapped('amount_payment')
                )
                partner_credit_limit = contract.credit_amount - used + amount_payment
            else:
                partner_credit_limit = contract.credit_amount - used

            partner_credit_limit -= contract.credit_amount_reserved

            if contract.state == 'active':
                contract.credit_amount_available = (
                    partner_credit_limit
                    if partner_credit_limit <= contract.credit_amount
                    else contract.credit_amount
                )
            else:
                contract.credit_amount_available = 0.00

    @api.onchange('contract_type_id')
    def onchange_contract_type_id(self):
        res = {}
        self.date_end = self.contract_type_id.expiration_date
        return res

    def action_create_sale_order(self):
        view_id = self.env.ref('sale.view_order_form').id
        context = self._context.copy()
        context.update({
            'default_partner_id': self.partner_id.id,
            'default_sofom_contract_id': self.id,
        })
        return {
            'name': 'Sale Order',
            'views': [(view_id, 'form')],
            'res_model': 'sale.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'res_id': 0,
            'target': 'current',
            'context': context,
        }

    def action_show_sales(self):
        self.ensure_one()
        tree_view = self.env.ref('sale.view_order_tree',
                                 raise_if_not_found=False)
        form_view = self.env.ref('sale.view_order_form',
                                 raise_if_not_found=False)

        context = self._context.copy()
        if self.state != 'active':
            context.update(create=False)
        else:
            context.update({
                'default_partner_id': self.partner_id.id,
                'default_sofom_contract_id': self.id,
            })

        action = {
            'type': 'ir.actions.act_window',
            'name': 'Sales Orders',
            'res_model': 'sale.order',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.order_ids.ids)],
            'context': context,
        }
        if tree_view and form_view:
            action['views'] = [(tree_view.id, 'tree'), (form_view.id, 'form')]
        return action

    def _get_action_invoice_name(self):
        return 'account.action_move_out_invoice_type'

    def action_create_invoice(self):
        self.ensure_one()
        form_view_ref = self.env.ref('account.view_move_form')
        result = self.env['ir.actions.act_window']._for_xml_id(
            self._get_action_invoice_name()
        )
        context = self._context.copy()
        if 'context' in result and type(result['context']) == str:
            context.update(ast.literal_eval(result['context']))
        else:
            context.update(result.get('context', {}))

        result['context'] = context
        result['context'].update({
            'default_partner_id': self.partner_id.id,
            'default_sofom_contract_id': self.id,
        })

        result.update({
            'views':  [(form_view_ref.id, 'form')],
        })

        return result

    def _domain_invoice(self):
        return [
            ('move_type', '=', 'out_invoice'),
            ('sofom_contract_id', '=', self.id)
        ]

    def action_show_invoices(self):
        self.ensure_one()
        form_view_ref = self.env.ref('account.view_move_form')
        tree_view_ref = self.env.ref('account.view_move_tree')

        result = self.env['ir.actions.act_window']._for_xml_id(
            self._get_action_invoice_name()
        )

        context = self._context.copy()
        if 'context' in result and type(result['context']) == str:
            context.update(ast.literal_eval(result['context']))
        else:
            context.update(result.get('context', {}))

        result['context'] = context
        if self.state != 'active':
            result['context'].update(create=False)
        else:
            result['context'].update({
                'default_partner_id': self.partner_id.id,
                'default_sofom_contract_id': self.id,
            })

        domain = self._domain_invoice()

        result.update({
            'domain': domain,
            'views':  [(tree_view_ref.id, 'tree'), (form_view_ref.id, 'form')],
        })

        return result

    def action_create_movement(self):
        # view_id = self.env.ref('sale.view_order_form').id
        context = self._context.copy()
        context.update({
            'default_sofom_contract_id': self.id,
        })
        return {
            'name': 'Credit Movement',
            # 'views': [(view_id, 'form')],
            'res_model': 'sofom.contract.movement',
            'view_id': False,
            'view_mode': 'form',
            'type': 'ir.actions.act_window',
            'res_id': 0,
            'target': 'new',
            'context': context,
        }

    def action_show_movements(self):
        self.ensure_one()
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Credit Movements',
            'res_model': 'sofom.contract.movement',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.movement_ids.ids)],
        }
        return action

    def name_get(self):
        name_template = _('%s - %s - Hectares: %s - Available: $ %s')
        res = [(contract.id, name_template % (
            contract.name,
            contract.contract_type_id.name,
            contract.hectares,
            format(contract.credit_amount_available, '.2f')
        )) for contract in self]
        return res

    def block_contract(self):
        self.write({'state': 'blocked'})

    def unblock_contract(self):

        self.write({'state': 'active'})
        self.contract_active_to_done()

    def active_contract(self):
        self.ensure_one()
        today = date.today()
        if today > self.date_end:
            raise ValidationError(
                _('Expiration date of the contract already expired.')
            )
        self.update({'state': 'active'})
        self.message_post(message_type="comment",
                          body='Se Activo el Contrato.')

    def cancel_contract(self):
        self.ensure_one()
        self.write({'state': 'cancelled'})

    @api.model
    def contract_active_to_done(self):
        today = date.today()
        contracts = self.search([
            ('state', 'in', ['active', 'blocked']),
            ('date_end', '<=', today)
        ])
        contracts.write({'state': 'done'})
        for contract in contracts:
            contract.message_post(message_type="comment",
                                  body='Se Concluyo el periodo del Contrato.')

    # cron
    @api.model
    def update_state(self):
        self.contract_active_to_done()

    # @api.constrains('radical_credit', 'radical_id')
    # def validate_radical_id(self):
    #     for record in self.filtered('radical_credit'):
    #         if record.radical_id == 0:
    #             raise ValidationError(
    #                 _('Radical ID required for this Contract.')
    #             )

    #         credit_type_count = self.sudo() \
    #             .search_count([('radical_id', '=', record.radical_id)])
    #         if credit_type_count > 1:
    #             raise ValidationError(
    #                 _('Contract with this Radical Id (%s) already exists.') %
    #                 record.radical_id
    #             )
