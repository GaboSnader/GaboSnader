from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.addons.account.models.account_move import AccountMove


class AccountInvoice(models.Model):
    _inherit = 'account.move'

    contract_id = fields.Many2one(
        'agv.contract',
        string='Contract',
        ondelete='restrict',
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="[('state', '=', 'active'), ('partner_id', '=', partner_id)]",
        check_company=True,
    )

    sofom_contract_id = fields.Many2one(
        'sofom.contract',
        string='Sofom Contract',
        ondelete='restrict',
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="[('state', '=', 'active'), ('partner_id', '=', partner_id)]",
    )

    @api.constrains('contract_id', 'sofom_contract_id', 'amount_total', 'move_type')
    def check_contract_amount(self):
        for account_move in self:
            if account_move.move_type != 'out_invoice':
                continue
            if (account_move.contract_id and
                    account_move.contract_id.credit_amount_available < account_move.amount_total):
                raise ValidationError(
                    _('Invoice exceeds available credit limit.'))
            if (account_move.sofom_contract_id and
                    account_move.sofom_contract_id.credit_amount_available < account_move.amount_total):
                raise ValidationError(
                    _('Invoice exceeds available credit limit.'))

    @api.constrains('contract_id', 'invoice_line_ids.sale_line_ids', 'sofom_contract_id')
    def check_contract_sale_order(self):
        for invoice in self:
            if not invoice.invoice_line_ids.mapped('sale_line_ids'):
                continue
            contract = invoice.invoice_line_ids \
                .mapped('sale_line_ids.order_id.contract_id')
            if len(contract) > 1:
                raise ValidationError(
                    ('Inconsistencia en lineas de factura con contrato en ventas.')
                )
            if invoice.contract_id != contract:
                raise ValidationError(
                    ('Inconsistencia en lineas de factura con contrato en ventas y factura.')
                )
            sofom_contract = invoice.invoice_line_ids \
                .mapped('sale_line_ids.order_id.sofom_contract_id')
            if len(contract) > 1:
                raise ValidationError(
                    ('Inconsistencia en lineas de factura con contrato en ventas.')
                )
            if invoice.sofom_contract_id != sofom_contract:
                raise ValidationError(
                    ('Inconsistencia en lineas de factura con contrato en ventas y factura.')
                )

    @api.onchange('partner_id')
    def _partner_onchange(self):
        res = {}
        if self.contract_id and self.contract_id.partner_id != self.partner_id:
            self.contract_id = None
        if self.sofom_contract_id and self.sofom_contract_id.partner_id != self.partner_id:
            self.sofom_contract_id = None
        return res

    @api.onchange('sofom_contract_id')
    def _sofom_contract_onchange(self):
        if self.sofom_contract_id:
            self.contract_id = None

    @api.onchange('contract_id')
    def _sofom_contract_onchange(self):
        if self.contract_id:
            self.sofom_contract_id = None

        if self.is_sale_document(include_receipts=True) and self.contract_id:
            if not self.contract_id.credit_type_id.account_id:
                raise ValidationError(
                    'Falta cuenta por configurar en credito.'
                )
            new_term_account = self.contract_id.credit_type_id.account_id
        elif self.is_sale_document(include_receipts=True) and self.partner_id and not self.contract_id:
            new_term_account = self.partner_id.commercial_partner_id.property_account_receivable_id
        else:
            new_term_account = None

        for line in self.line_ids:
            if new_term_account and line.account_id.user_type_id.type in ('receivable', 'payable'):
                line.account_id = new_term_account

        self._recompute_dynamic_lines()


outer = AccountMove._recompute_payment_terms_lines


def create_inner():
    def _get_payment_terms_account(self, payment_terms_lines):
        if payment_terms_lines:
            return payment_terms_lines[0].account_id
        elif self.contract_id:
            return self.contract_id.credit_type_id.account_id
        elif self.partner_id:
            # Retrieve account from partner.
            if self.is_sale_document(include_receipts=True):
                return self.partner_id.property_account_receivable_id
            else:
                return self.partner_id.property_account_payable_id
        else:
            # Search new account.
            domain = [
                ('company_id', '=', self.company_id.id),
                ('internal_type', '=', 'receivable' if self.move_type in (
                    'out_invoice', 'out_refund', 'out_receipt') else 'payable'),
            ]
            return self.env['account.account'].search(domain, limit=1)
    return _get_payment_terms_account


def replace_inner_function(outer, new_inner):
    """Replace a nested function code object used by outer with new_inner

    The replacement new_inner must use the same name and must at most use the
    same closures as the original.

    """
    if hasattr(new_inner, '__code__'):
        # support both functions and code objects
        new_inner = new_inner.__code__

    # find original code object so we can validate the closures match
    ocode = outer.__code__
    function, code = type(outer), type(ocode)
    iname = new_inner.co_name
    orig_inner = next(
        const for const in ocode.co_consts
        if isinstance(const, code) and const.co_name == iname)

    # you can ignore later closures, but since they are matched by position
    # the new sequence must match the start of the old.
    assert (orig_inner.co_freevars[:len(new_inner.co_freevars)] ==
            new_inner.co_freevars), 'New closures must match originals'

    # replace the code object for the inner function
    new_consts = tuple(
        new_inner if const is orig_inner else const
        for const in outer.__code__.co_consts)

    # create a new code object with the new constants
    try:
        # Python 3.8 added code.replace(), so much more convenient!
        ncode = ocode.replace(co_consts=new_consts)
    except AttributeError:
        # older Python versions, argument counts vary so we need to check
        # for specifics.
        args = [
            ocode.co_argcount, ocode.co_nlocals, ocode.co_stacksize,
            ocode.co_flags, ocode.co_code,
            new_consts,  # replacing the constants
            ocode.co_names, ocode.co_varnames, ocode.co_filename,
            ocode.co_name, ocode.co_firstlineno, ocode.co_lnotab,
            ocode.co_freevars, ocode.co_cellvars,
        ]
        if hasattr(ocode, 'co_kwonlyargcount'):
            # Python 3+, insert after co_argcount
            args.insert(1, ocode.co_kwonlyargcount)
        # Python 3.8 adds co_posonlyargcount, but also has code.replace(), used above
        ncode = code(*args)

    # and a new function object using the updated code object
    return function(
        ncode, outer.__globals__, outer.__name__,
        outer.__defaults__, outer.__closure__
    )


new_inner = create_inner()
AccountMove._recompute_payment_terms_lines = replace_inner_function(
    AccountMove._recompute_payment_terms_lines, new_inner)
