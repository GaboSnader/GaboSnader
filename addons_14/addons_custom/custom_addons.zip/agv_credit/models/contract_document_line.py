from datetime import date
from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class ContractDocument(models.Model):
    _name = "agv.contract.document.line"
    _description = "Contract Document Line"

    contract_id = fields.Many2one(
        'agv.contract',
        string="Contract"
    )

    credit_document_id = fields.Many2one(
        'credit.document.line',
        string="Credit Document Line"
    )

    document_type_id = fields.Many2one(
        'document.type',
        # related='credit_document_id.document_type_id',
        required=True
    )

    mandatory_no_company_partner = fields.Boolean(
        related='credit_document_id.mandatory_no_company_partner',
        store=True
    )

    mandatory_company_partner = fields.Boolean(
        related='credit_document_id.mandatory_company_partner',
        store=True
    )

    delivery_date = fields.Date()

    file_attachment = fields.Binary(store=False)
    attachment_id = fields.Many2one('ir.attachment')

    notes = fields.Text(string="Observaciones")

    validate = fields.Boolean(default=False)
    validate_date = fields.Date()
    validate_user_id = fields.Many2one('res.users')

    is_valid = fields.Boolean(compute='_compute_is_valid')

    @api.model
    def create(self, vals):
        contract = self.env['agv.contract'].browse(vals['contract_id'])
        partner = contract.partner_id
        document = partner.document_ids.filtered(
            lambda document: (
                document.document_type_id.id == vals['document_type_id'] and
                document.document_active
            )
        )
        if document:
            vals['attachment_id'] = document.attachment.id
        return super(ContractDocument, self).create(vals)

    def _search_in_partner(self):
        for document_line in self:
            contract = document_line.contract_id
            partner = contract.partner_id
            document = partner.document_ids.filtered(
                lambda document, dl=document_line: (
                    document.document_type_id.id == dl.document_type_id.id and
                    document.document_active
                )
            )
            if document:
                document_line.attachment_id = document.attachment.id

    def write(self, vals):

        for document in self:
            if (not document.attachment_id and
                not vals.get('file_attachment') and
                    not vals.get('attachment_id')):
                raise ValidationError(_('Required file.'))

        if vals.get('file_attachment', False):
            vals_name = {
                'partner_id': self.contract_id.partner_id.id,
                'expiration_date': ''
            }
            name = self.env['res.partner.document'] \
                .generate_attachment_name(vals_name)
            attachment = {
                'name': name,
                'datas': vals['file_attachment'],
            }
            attachment = self.env['ir.attachment'].sudo().create(attachment)
            vals['attachment_id'] = attachment.id
            vals['delivery_date'] = date.today()
        if vals.get('validate'):
            vals['validate_date'] = date.today()
            vals['validate_user_id'] = self.env.user.id
        return super(ContractDocument, self).write(vals)

    def _compute_is_valid(self):
        for document in self:
            if document.validate:
                document.is_valid = True
                continue
            is_company = document.contract_id.partner_id.is_company
            if is_company:
                if document.mandatory_company_partner:
                    document.is_valid = False
                else:
                    document.is_valid = True
            else:
                if document.mandatory_no_company_partner:
                    document.is_valid = False
                else:
                    document.is_valid = True
