import base64
import operator
import re

from odoo import api, fields, models, tools, _
from odoo.http import request
from odoo.modules import get_module_resource


class IrUiMenu(models.Model):
    _inherit = 'ir.ui.menu'

    # @api.returns('self')
    # def _filter_visible_menus(self):
    #     result = super(IrUiMenu, self)._filter_visible_menus()
    #     if self.env.user.company_id.id != 1:
    #         result = result - \
    #             self.browse(self.env.ref("agv_credit.menu_credit").id)
    #     return result
