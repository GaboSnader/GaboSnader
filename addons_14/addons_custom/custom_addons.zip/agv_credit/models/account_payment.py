from odoo import models, api, fields
#from odoo.exceptions import Warning, ValidationError


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    # contract_id = fields.Many2one(
    #     'agv.contract',
    #     string='Contract',
    #     ondelete='restrict'
    # )

    # radical_id = fields.Integer()

    # def _send_radical(self):
    #     return False, 'No Implementacion Radical.'

    # @api.multi
    # def post(self):
    #     if not self.invoice_ids.contract_id:
    #         return super(AccountPayment, self).post()

    #     if self.invoice_ids.contract_id.radical_credit:

    #         success, radical_response = self._send_radical()

    #         if not success:  # TODO: Translate
    #             raise ValidationError(
    #                 'No se pudo registrar en radical el pago. '
    #                 'Error: ' + radical_response
    #             )
    #     else:
    #         # TODO: Proceso Pendiente
    #         return super(AccountPayment, self).post()
