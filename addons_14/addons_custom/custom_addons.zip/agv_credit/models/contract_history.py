
from odoo import models, fields, api


class ContractHistory(models.Model):
    _name = 'agv.contract.history'
    _description = 'Contract History'

    contract_id = fields.Many2one(
        'agv.contract',
        string='Contract'
    )

    description = fields.Text(string='Description')
    user_id = fields.Many2one('res.users')
    model_id = fields.Integer()
    model_name = fields.Char()
    # amount = fields.Monetary(string="Total")
    # currency_id = \
    #     fields.Many2one('res.currency',
    #                     related='contract_id.currency_id',
    #                     store=True,
    #                     readonly=True)
