
from . import account_invoice
#from . import contract_history
from . import account_payment
from . import contract
from . import sofom_contract
from . import contract_action_wizard
from . import contract_type
from . import sale_order
from . import contract_document_line
from . import credit_type
from . import res_partner

from . import ir_ui_menu
