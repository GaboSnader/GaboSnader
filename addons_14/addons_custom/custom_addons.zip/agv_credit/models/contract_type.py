from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

# TODO: Preguntar que datos ya no se pueden modificar


class ContractType(models.Model):
    _name = 'contract.type'
    _description = 'Contract Type'

    name = fields.Char(
        string='Contract Type Name',
        required=True
    )

    folio = fields.Char(readonly=True)

    description = fields.Text(string='Contract Type Description')

    credit_type_id = fields.Many2one(
        'credit.type',
        required=True,
        ondelete='restrict',
    )

    expiration_date = fields.Date(
        required=True,
    )

    # country_id = fields.Many2one(
    #     'res.country',
    #     string='Country',
    #     ondelete='restrict'
    # )

    # state_id = fields.Many2one(
    #     "res.country.state",
    #     string='State',
    #     ondelete='restrict',
    #     domain="[('country_id', '=?', country_id)]"
    # )

    radical_credit = fields.Boolean(
        related='credit_type_id.radical_credit',
        store=True,
        readonly=True
    )

    radical_id = fields.Integer()

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         'Name is already assigned.')
    ]

    def name_get(self):
        name_template = '%s - %s'
        res = [(contract_type.id, name_template % (
            contract_type.credit_type_id.name,
            contract_type.name,
        )) for contract_type in self]
        return res

    def _get_folio(self):
        self.ensure_one()
        if not self.id:
            return ''
        return str(self.id).zfill(5)

    @api.model
    def create(self, vals):
        res = super(ContractType, self).create(vals)
        res.folio = res._get_folio()
        return res

    # @api.onchange('all_warehouse')
    # def _all_warehouse_onchange(self):
    #     if self.all_warehouse:
    #         warehouse = self.env['stock.warehouse'].sudo().search([]) TODO: company
    # warehouse = self.env['stock.warehouse'] \
    #             .search([
    #                 '|',
    #                 ('company_id', '=', self.company_id.id),
    #                 ('company_id', 'child_of', [self.company_id.id])
    #             ])
    #         warehouse_ids = map(lambda wh: wh.id, warehouse)
    #         values = {
    #             'warehouse_ids': list(warehouse_ids)
    #         }
    #         self.update(values)
    #     else:
    #         values = {
    #             'warehouse_ids': [[5]]
    #         }
    #         self.update(values)

    @api.constrains('expiration_date')
    def check_date(self):
        today = date.today()
        if self.expiration_date < today:
            raise ValidationError(_('Invalid Expiration Date.'))

    # @api.constrains('warehouse_ids')
    # def check_warehouses(self):
    #     if not self.warehouse_ids:
    #         raise ValidationError(_('1 Minimun Warehouse.'))

    # @api.constrains('radical_id')
    # def validate_radical_id(self):
    #     for record in self:
    #         contract_type_count = self.sudo() \
    #             .search_count([('radical_id', '=', record.radical_id)])
    #         if contract_type_count > 1:
    #             raise ValidationError(
    #                 _('Contract Type with this Radical Id (%s) already exists.') %
    #                 record.radical_id
    #             )

    # @api.model
    # def create(self, vals):
    #     if 'all_warehouse' in vals:
    #         vals = self.all_warehouse_check(vals)
    #     return super(ContractType, self).create(vals)

    # def write(self, vals):
    #     if 'all_warehouse' in vals:
    #         vals = self.all_warehouse_check(vals)
    #     return super(ContractType, self).write(vals)

    # def all_warehouse_check(self, vals):
    #     if vals['all_warehouse']:
    #         warehouse = self.env['stock.warehouse'].sudo().search([])
    #         warehouse_ids = map(lambda wh: [4, wh.id], warehouse)
    #         vals['warehouse_ids'] = list(warehouse_ids)
    #     return vals
