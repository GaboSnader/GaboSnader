from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    contract_id = fields.Many2one(
        'agv.contract',
        string='Contract',
        ondelete='restrict',
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="[('state', '=', 'active'), ('partner_id', '=', partner_id)]",
        check_company=True,
    )

    sofom_contract_id = fields.Many2one(
        'sofom.contract',
        string='Sofom Contract',
        ondelete='restrict',
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="[('state', '=', 'active'), ('partner_id', '=', partner_id)]",
    )

    @api.constrains('contract_id', 'sofom_contract_id', 'amount_total')
    def check_contract_amount(self):
        if self.contract_id and self.contract_id.credit_amount_available < self.amount_total:
            raise ValidationError(_('Order exceeds available credit limit.'))
        if self.sofom_contract_id and self.sofom_contract_id.credit_amount_available < self.amount_total:
            raise ValidationError(_('Order exceeds available credit limit.'))

    @api.onchange('partner_id')
    def _partner_onchange(self):
        res = {}
        res['domain'] = {
            'contract_id': [
                ('partner_id', '=', self.partner_id.id),
                ('state', '=', 'active')
            ],
            'sofom_contract_id': [
                ('partner_id', '=', self.partner_id.id),
                ('state', '=', 'active')
            ]
        }
        if self.contract_id and self.contract_id.partner_id != self.partner_id:
            self.contract_id = None
        if self.sofom_contract_id and self.sofom_contract_id.partner_id != self.partner_id:
            self.sofom_contract_id = None
        return res

    @api.model
    def create(self, vals):
        if 'order_line' not in vals:
            raise ValidationError(_('Minimum one product line.'))
        res = super(SaleOrder, self).create(vals)
        return res

    def _prepare_invoice(self):
        invoice_vals = super(SaleOrder, self)._prepare_invoice()
        if self.contract_id:
            invoice_vals['contract_id'] = self.contract_id.id
        elif self.sofom_contract_id:
            invoice_vals['sofom_contract_id'] = self.sofom_contract_id.id
        return invoice_vals

    def _get_invoice_grouping_keys(self):
        result = super(SaleOrder, self)._get_invoice_grouping_keys()
        result += ['contract_id', 'sofom_contract_id']
        return result
