import ast
from datetime import date
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class AGVContract(models.Model):
    _name = 'agv.contract'
    _description = "Contract"
    _order = 'name asc'
    _inherit = [
        'mail.thread',
        'mail.activity.mixin',
    ]

    name = fields.Char(
        readonly=True,
    )

    id_credit = fields.Char(
        readonly=True,
    )

    partner_id = fields.Many2one(
        'res.partner',
        string="Customer",
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
    )

    customer_code = fields.Char(
        related='partner_id.customer_code',
        readonly=True,
    )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Draft Sent'),
        ('rejected', 'Rejected'),
        ('conditioned', 'Conditioned'),
        ('approval_table', 'Approval table'),
        ('blocked', 'Blocked'),
        ('active', 'Active'),
        ('done', 'Done'),
    ], string='Status', default='draft', copy=False, readonly=True)

    sale_count = fields.Integer(compute="_compute_sale_count")
    invoice_count = fields.Integer(compute="_compute_invoice_count")

    date_end = fields.Date(
        readonly=True,
        required=True,
        states={
            'draft': [('readonly', False)],
            'conditioned': [('readonly', False)]
        }
    )

    unalterable_date_end = fields.Boolean(
        related='credit_type_id.unalterable_date',
        store=True
    )

    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.user.company_id,
        readonly=True,
    )

    warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='Warehouse',
        readonly=True,
        required=True,
        states={'draft': [('readonly', False)]}
    )

    contract_type_id = fields.Many2one(
        'contract.type',
        string='Contract Type',
        ondelete='restrict',
        required=True,
        readonly=True,
        domain=[
            ('expiration_date', '>=', date.today()),
            ('radical_credit', '=', False)
        ],
        states={'draft': [('readonly', False)]}
    )

    currency_id = fields.Many2one(
        'res.currency',
        string="Currency",
        related='company_id.currency_id',
        readonly=True,
        # states={'draft': [('readonly', False)]}
    )

    note = fields.Text(string="Notes")

    per_hectare = fields.Boolean(
        related='credit_type_id.per_hectare',
        store=True,
        readonly=True
    )

    hectares = fields.Float(
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    credit_amount = fields.Monetary(
        readonly=True,
        states={'draft': [('readonly', False)]}
    )

    credit_amount_available = fields.Monetary(
        string="Credit Available",
        compute='_compute_credit_amount',
        store=True
    )

    credit_amount_used = fields.Monetary(
        string="Credit Used",
        compute='_compute_credit_amount',
        store=True
    )

    amount_to_reconcile = fields.Monetary(
        string="Pending To Reconcile",
        compute='_compute_credit_amount',
        store=True
    )

    credit_amount_reserved = fields.Monetary(
        string="Credit Reserved",
        compute='_compute_amount_reserved',
        store=True
    )

    order_ids = fields.One2many(
        'sale.order',
        inverse_name='contract_id',
        string='Sale Orders'
    )

    invoice_ids = fields.One2many(
        'account.move',
        inverse_name='contract_id',
        string='Invoice'
    )

    document_ids = fields.One2many(
        'agv.contract.document.line',
        inverse_name='contract_id',
        string='Contract Document'
    )

    revolving_credit = fields.Boolean(
        related='credit_type_id.revolving_credit',
        store=True,
        readonly=True
    )

    credit_type_id = fields.Many2one(
        'credit.type',
        related='contract_type_id.credit_type_id',
        store=True,
        readonly=True
    )

    document_search_available = fields.Boolean(
        compute='_compute_document_def_available'
    )

    document_validation_available = fields.Boolean(
        compute='_compute_document_def_available'
    )

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         'Name is already assigned.'),
        ('credit_amount_minimun',
         'CHECK(credit_amount > 0.00)',
         'Credit amount cannot be 0.00 or less.')
    ]

    @api.constrains('hectares', 'per_hectare')
    def check_contract_hectare(self):
        for contract in self:
            if contract.per_hectare and contract.hectares <= 0.00:
                raise ValidationError(('Hectareas Necesarias'))

    def _compute_sale_count(self):
        for rec in self:
            rec.sale_count = len(rec.order_ids)

    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = len(rec.invoice_ids.filtered(
                lambda move: move.move_type == 'out_invoice'
            ))

    def _compute_document_def_available(self):
        for contract in self:
            if contract.state not in ('draft', 'conditioned'):
                contract.document_validation_available = False
                contract.document_search_available = False
                continue
            documents = contract.document_ids
            documents_no_attachment = documents.filtered(
                lambda document: not document.attachment_id
            )
            documents_no_validated = documents.filtered(
                lambda document: (
                    not document.validate and document.attachment_id
                )
            )
            if documents_no_validated:
                contract.document_validation_available = True
            else:
                contract.document_validation_available = False
            if documents_no_attachment:
                contract.document_search_available = True
            else:
                contract.document_search_available = False

    def _get_contract_name(self):
        self.ensure_one()
        if not self.warehouse_id or not self.id:
            return ''
        warehouse_name_format = self.warehouse_id.name \
            .replace(' ', '')[:3].upper()
        return warehouse_name_format \
            + '-' + str(self.id).zfill(8)

    def _get_id_credit(self):
        self.ensure_one()
        if not self.id:
            return ''
        return str(self.id).zfill(8)

    @api.depends('order_ids.order_line.invoice_lines.price_total', 'state')
    def _compute_amount_reserved(self):
        for contract in self:
            amount_reserved = 0.00
            orders = contract.order_ids.filtered(
                lambda order: (
                    order.state == 'sale' and
                    order.invoice_status != 'invoiced'
                )
            )
            for order in orders:
                amount_reserved += order.amount_total

                invoice_lines = order.order_line.invoice_lines.filtered(
                    lambda move_line: move_line.parent_state == 'posted'
                )

                if not invoice_lines:
                    continue

                amount_invoiced = sum(invoice_lines.mapped('price_total'))
                amount_reserved -= amount_invoiced
            contract.credit_amount_reserved = amount_reserved

    @api.depends('invoice_ids.amount_residual',
                 'invoice_ids.state',
                 'state',
                 'credit_amount_reserved')
    def _compute_credit_amount(self):
        for contract in self:
            if contract.state in ('draft', 'sent', 'approve'):
                contract.credit_amount_available = 0.00
                contract.credit_amount_used = 0.00
                contract.amount_to_reconcile = 0.00
                continue

            invoices = contract.invoice_ids \
                .filtered(lambda move: (
                    move.move_type == 'out_invoice' and
                    move.state == 'posted'
                ))

            used = 0.0
            reconcile_pending = 0.0
            for invoice in invoices:
                used += invoice.amount_total

                content = invoice._get_reconciled_info_JSON_values()
                move_ids = [move['move_id'] for move in content]

                refund_ids = self.env['account.move'].browse(move_ids) \
                    .filtered(lambda move: move.move_type == 'out_refund')

                for refund in invoice.refund_invoice_ids.filtered(lambda move: move.state == 'posted'):
                    if refund not in refund_ids:
                        reconcile_pending += refund.amount_total
                    else:
                        used -= refund.amount_total

            used_no_pay = sum(invoices.mapped('amount_residual'))

            contract.credit_amount_used = used
            contract.amount_to_reconcile = reconcile_pending

            if contract.revolving_credit:
                partner_credit_limit = contract.credit_amount - used_no_pay
            else:
                partner_credit_limit = contract.credit_amount - used

            partner_credit_limit -= contract.credit_amount_reserved

            if contract.state == 'active':
                contract.credit_amount_available = (
                    partner_credit_limit
                    if partner_credit_limit <= contract.credit_amount
                    else contract.credit_amount
                )
            else:
                contract.credit_amount_available = 0.00

    @api.onchange('contract_type_id')
    def onchange_contract_type_id(self):
        res = {}
        self.date_end = self.contract_type_id.expiration_date
        return res

    @api.model
    def create(self, vals):
        contract_type = self.env['contract.type'] \
            .sudo().browse(vals['contract_type_id'])
        vals['document_ids'] = self._get_documents(contract_type)

        res = super(AGVContract, self).create(vals)
        res.name = res._get_contract_name()
        res.id_credit = res._get_id_credit()
        # res.message_subscribe([res.partner_id.id])
        return res

    def write(self, vals):
        if vals.get('contract_type_id'):
            if self.document_ids:
                self.document_ids.unlink()
            contract_type = self.env['contract.type'] \
                .sudo().browse(vals['contract_type_id'])
            vals['document_ids'] = self._get_documents(contract_type)
        return super(AGVContract, self).write(vals)

    def _get_documents(self, contract_type):
        documents = contract_type.credit_type_id.document_ids
        document_ids = [
            (0, 0, {
                'credit_document_id': document.id,
                'document_type_id': document.document_type_id.id
            })
            for document in documents
        ]
        return document_ids

    def action_create_sale_order(self):
        view_id = self.env.ref('sale.view_order_form').id
        context = self._context.copy()
        context.update({
            'default_partner_id': self.partner_id.id,
            'default_contract_id': self.id,
        })
        return {
            'name': 'Sale Order',
            'views': [(view_id, 'form')],
            'res_model': 'sale.order',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'res_id': 0,
            'target': 'current',
            'context': context,
        }

    def action_show_sales(self):
        self.ensure_one()
        tree_view = self.env.ref('sale.view_order_tree',
                                 raise_if_not_found=False)
        form_view = self.env.ref('sale.view_order_form',
                                 raise_if_not_found=False)
        context = self._context.copy()
        if self.state != 'active':
            context.update(create=False)
        else:
            context.update({
                'default_partner_id': self.partner_id.id,
                'default_contract_id': self.id,
            })
        context.update({
            'default_partner_id': self.partner_id.id,
            'default_contract_id': self.id,
        })
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Sales Orders',
            'res_model': 'sale.order',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.order_ids.ids)],
            'context': context,
        }
        if tree_view and form_view:
            action['views'] = [(tree_view.id, 'tree'), (form_view.id, 'form')]
        return action

    def _get_action_invoice_name(self):
        return 'account.action_move_out_invoice_type'

    def action_create_invoice(self):
        self.ensure_one()

        result = self.env['ir.actions.act_window']._for_xml_id(
            self._get_action_invoice_name()
        )
        context = self._context.copy()
        if 'context' in result and type(result['context']) == str:
            context.update(ast.literal_eval(result['context']))
        else:
            context.update(result.get('context', {}))

        result['context'] = context
        result['context'].update({
            'default_partner_id': self.partner_id.id,
            'default_contract_id': self.id,
        })

        form_id = None
        for f_id, form_type in result['views']:
            if form_type == 'form':
                form_id = f_id
                break

        if not form_id:
            form_id = self.env.ref('account.view_move_form').id

        result.update({
            'views':  [(form_id, 'form')],
        })

        return result

    def _domain_invoice(self):
        return [
            ('move_type', '=', 'out_invoice'),
            ('contract_id', '=', self.id)
        ]

    def action_show_invoices(self):
        self.ensure_one()

        result = self.env['ir.actions.act_window']._for_xml_id(
            self._get_action_invoice_name()
        )

        context = self._context.copy()
        if 'context' in result and type(result['context']) == str:
            context.update(ast.literal_eval(result['context']))
        else:
            context.update(result.get('context', {}))

        result['context'] = context
        if self.state != 'active':
            result['context'].update(create=False)
        else:
            result['context'].update({
                'default_partner_id': self.partner_id.id,
                'default_contract_id': self.id,
            })

        domain = self._domain_invoice()

        result.update({
            'domain': domain,
        })

        return result

    def name_get(self):
        name_template = _('%s - %s - Hectares: %s - Available: $ %s')
        res = [(contract.id, name_template % (
            contract.name,
            contract.contract_type_id.name,
            contract.hectares,
            format(contract.credit_amount_available, '.2f')
        )) for contract in self]
        return res

    def search_document_and_add(self):
        self.ensure_one()
        document_missing = self.document_ids.filtered(
            lambda document: not document.attachment_id
        )
        if not document_missing:
            return
        document_missing._search_in_partner()

    def validate_document_delivered(self):
        self.ensure_one()
        documents = self.document_ids.filtered(
            lambda document: not document.validate and document.attachment_id
        )
        if documents:
            documents.write({'validate': True})
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    def block_contract(self):
        self.write({'state': 'blocked'})

    def unblock_contract(self):

        self.write({'state': 'active'})
        self.contract_active_to_done()

    def sent_contract_to_approve(self):
        self.ensure_one()
        if not all(self.document_ids.mapped('is_valid')):
            raise ValidationError(_('Missing documents approval.'))
        self.update({'state': 'sent'})
        self.message_post(message_type="comment",
                          body='Se Envio Solicitud para Aprovacion.')

        # self.activity_schedule(summary='Authorizar Contracto',
        #                        note='<p>Authorizar Contract</p>',
        #                        activity_type_id=4,
        #                        user_id=self.credit_type_id.user_id.id)

        # users_to_notify = self.env.ref('agv_credit.can_approve_contract').users
        # # Subscribe reviewers and notify
        # self.message_post(
        #     partner_ids=users_to_notify.mapped("partner_id").ids,
        #     subtype_xmlid=self._get_requested_notification_subtype(),
        #     body=self._notify_requested_review_body(),
        # )

    def approve_auth_contract(self):
        self.ensure_one()
        today = date.today()
        if today > self.date_end:
            raise ValidationError(
                _('Expiration date of the contract already expired.')
            )
        self.update({'state': 'approval_table'})
        self.message_post(message_type="comment",
                          body='Se Envio Solicitud a Mesa de Control.')

    def approve_approval_table_contract(self):
        self.ensure_one()
        today = date.today()
        if today > self.date_end:
            raise ValidationError(
                _('Expiration date of the contract already expired.')
            )
        self.update({'state': 'active'})
        self.message_post(message_type="comment",
                          body='Se Autorizo el Contrato por Mesa de Control.')

    def condition_contract(self):
        view_id = self.env.ref('agv_credit.agv_contract_wizard_form_view').id
        context = self._context.copy()
        context['model'] = 'agv.contract'
        context['model_id'] = self.id
        context['message'] = 'Razon de Condicionar la Solicitud de Contrato.'
        context['def'] = 'sent_contract_to_conditioned'
        return {
            'name': 'Condition',
            'views': [(view_id, 'form')],
            'res_model': 'agv.contract.wizard',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': context,
        }

    def refuse_auth_contract(self):
        view_id = self.env.ref('agv_credit.agv_contract_wizard_form_view').id
        context = self._context.copy()
        context['model'] = 'agv.contract'
        context['model_id'] = self.id
        context['message'] = 'Razon del Rachazo de Solicitud de Contrato.'
        context['def'] = 'sent_contract_to_rejected'
        return {
            'name': 'Refuse',
            'views': [(view_id, 'form')],
            'res_model': 'agv.contract.wizard',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context': context,
        }

    def sent_contract_to_rejected(self, msg):
        self.ensure_one()
        self.write({'state': 'rejected'})
        self.message_post(message_type="comment",
                          body='Se Rechazo la Solicitud de Credito.\n Razon: ' + msg)

    def sent_contract_to_conditioned(self, msg):
        self.ensure_one()
        self.write({'state': 'conditioned'})
        self.message_post(message_type="comment",
                          body='Se Condiciono la Solicitud de Credito.\n Razon: ' + msg)

    @api.model
    def contract_active_to_done(self):
        today = date.today()
        contracts = self.search([
            ('state', 'in', ['active', 'blocked']),
            ('date_end', '<=', today)
        ])
        contracts.write({'state': 'done'})
        for contract in contracts:
            contract.message_post(message_type="comment",
                                  body='Se Concluyo el periodo del Contrato.')

    # cron
    @api.model
    def update_state(self):
        self.contract_active_to_done()
