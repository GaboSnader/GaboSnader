{
    'name': "agv_credit",

    'summary': """ Contracts """,

    'author': "Edgar Inzunza",

    'category': 'Uncategorized',

    # any module necessary for this one to work correctly
    'depends': [
        'sale',
        'account',
        'document_type_and_partner_document',
        'account_invoice_refund_link',
        'report_xlsx_helper',
        'agv_res_partner_extra',
    ],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/groups.xml',
        # 'data/mail_data.xml',
        'views/contract_menuitem.xml',
        'views/contract.xml',
        'views/contract_type.xml',
        'views/credit_type.xml',
        'views/sofom_contract.xml',
        'views/sofom_contract_movement.xml',
        # 'views/res_partner.xml',
        # 'views/res_company.xml',
        'views/sale_order.xml',
        'wizard/contract_action_wizard.xml',
        'wizard/contract_report_wizard.xml',
        'report/report_contract.xml',
        'views/account_invoice.xml',
        # 'data/ir_cron_contract.xml',
    ],
}
