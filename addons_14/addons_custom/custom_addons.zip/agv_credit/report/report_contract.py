from odoo.addons.report_xlsx_helper.report.report_xlsx_format import (
    FORMATS,
    XLS_HEADERS,
)
from odoo import models


class ContractXlsx(models.AbstractModel):
    _name = 'report.contract.list'
    _description = "Report xlsx Contract"
    _inherit = 'report.report_xlsx.abstract'

    def _get_ws_params(self, wb, data, contracts):

        contract_template = {
            "name": {
                "header": {
                    "value": "Name",
                },
                "data": {
                    "value": self._render("contract.name"),
                },
                "width": 20,
            },
            "partner_id": {
                "header": {
                    "value": "Contact",
                },
                "data": {
                    "value": self._render("contract.partner_id.name"),
                },
                "width": 20,
            },
            "credit_type_id": {
                "header": {
                    "value": "Credit Type",
                },
                "data": {
                    "value": self._render("contract.credit_type_id.name"),
                },
                "width": 20,
            },
            "contract_type_id": {
                "header": {
                    "value": "Contract Type",
                },
                "data": {
                    "value": self._render("contract.contract_type_id.name"),
                },
                "width": 20,
            },
            "credit_amount": {
                "header": {
                    "value": "Credit Amount",
                },
                "data": {
                    "value": self._render("contract.credit_amount"),
                },
                "width": 20,
            },
            "credit_amount_available": {
                "header": {
                    "value": "Credit Available",
                },
                "data": {
                    "value": self._render("contract.credit_amount_available"),
                },
                "width": 20,
            },
            "credit_amount_used": {
                "header": {
                    "value": "Credit Used",
                },
                "data": {
                    "value": self._render("contract.credit_amount_used"),
                },
                "width": 20,
            },
            "create_uid": {
                "header": {
                    "value": "Create User",
                },
                "data": {
                    "value": self._render("contract.create_uid.name"),
                },
                "width": 20,
            },
            "create_date": {
                "header": {
                    "value": "Create Date",
                },
                "data": {
                    "value": self._render("contract.create_date"),
                },
                "width": 20,
            },
            "date_end": {
                "header": {
                    "value": "Date end",
                },
                "data": {
                    "value": self._render("contract.date_end"),
                },
                "width": 20,
            },
            "state": {
                "header": {
                    "value": "State",
                },
                "data": {
                    "value": self._render("state"),
                },
                "width": 20,
            },
        }

        wanted_list = contract_template.keys()
        ws_params = {
            "ws_name": "Contracts",
            "generate_ws_method": "_contract_report",
            "title": "Contracts",
            "wanted_list": wanted_list,
            "col_specs": contract_template,
        }

        return [ws_params]

    def _contract_report(self, workbook, ws, ws_params, data, contracts):

        ws.set_portrait()
        ws.fit_to_pages(1, 0)
        ws.set_header(XLS_HEADERS["xls_headers"]["standard"])
        ws.set_footer(XLS_HEADERS["xls_footers"]["standard"])

        self._set_column_width(ws, ws_params)

        row_pos = 0
        if len(contracts) == 1:
            ws_params["title"] = contracts.name
        row_pos = self._write_ws_title(ws, row_pos, ws_params)
        row_pos = self._write_line(
            ws,
            row_pos,
            ws_params,
            col_specs_section="header",
            default_format=FORMATS["format_theader_yellow_left"],
        )
        ws.freeze_panes(row_pos, 0)

        wl = ws_params["wanted_list"]

        states = dict(contracts._fields['state'].selection)

        for contract in contracts:
            state = states.get(contract.state)
            row_pos = self._write_line(
                ws,
                row_pos,
                ws_params,
                col_specs_section="data",
                render_space={
                    "contract": contract,
                    "state": state
                },
                default_format=FORMATS["format_tcell_left"],
            )
