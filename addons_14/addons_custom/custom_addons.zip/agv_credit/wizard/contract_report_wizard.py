import ast
from datetime import date
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class ChangePasswordWizard(models.TransientModel):
    _name = "agv.contract.report.wizard"
    _description = "Partner Change External Password Wizard"

    date_start = fields.Date()
    date_end = fields.Date()

    export_type = fields.Selection([
        ('PDF', 'PDF'),
        ('xlxs', 'Excel'),
    ], default="PDF", required=True)

    def _print_pdf(self, contracts):
        action = self.env.ref('agv_credit.action_report_contract_pdf')\
            .report_action(contracts)
        action.update({'close_on_report_download': True})
        return action

    def _print_xlsx(self, contracts):
        action = self.env.ref('agv_credit.action_report_contract_xlsx')\
            .report_action(contracts)
        action.update({'close_on_report_download': True})
        return action

    def ok(self):
        contracts = self.env['agv.contract'].search([])
        print(self.export_type)
        if self.export_type == 'PDF':
            return self._print_pdf(contracts)
        return self._print_xlsx(contracts)
