This module shows the links between refunds and their original invoices in the
invoice form and also keep track of refund lines and their original invoice
lines.
