This module demonstrates the capabilities or the report_xlsx_helper module via
a basic example.
