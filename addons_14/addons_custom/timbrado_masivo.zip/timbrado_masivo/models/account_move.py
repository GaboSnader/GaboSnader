# -*- coding: utf-8 -*-

import logging

from odoo import _, api, fields, models
from datetime import datetime

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'

    def invoices_to_stamp(self):
        invoice_ids = self.env['account.move'].search([('partner_id', '=', self.partner_id.id)])

class WizardMassStamping(models.TransientModel):
    _name = 'wizard.mass.stamping'

    invoice_select = fields.Selection([('partner', 'Cliente'),('date', 'Fecha factura')], string='Seleccionar por', default="partner")
    date = fields.Date(string="Fecha factura")
    partner_id = fields.Many2one('res.partner', string="Cliente")

    def save(self):
        if self.invoice_select == 'partner':
            invoice_ids = self.env['account.move'].search([('partner_id', '=', self.partner_id.id)])
        elif self.invoice_select == 'date':
            invoice_ids = self.env['account.move'].search([('invoice_date', '=', self.date)])
        for inv in invoice_ids:
            print("############## SAVE >>>>>>>>>>>>>>>>>> ")
            if inv.state != 'cancel' and inv.l10n_mx_edi_sat_status not in ['valid', 'cancelled'] and inv.move_type == 'out_invoice':
                print("############# CONDICION >>>>>>>>>>>>>>>>>>")
                inv._post()
                inv.l10n_mx_edi_update_sat_status()
