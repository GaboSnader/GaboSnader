#-*- coding: utf-8 -*-
{
    'name': "Timbrado masivo de facturas",
    'summary': """
        Módulo complementario de facturacion y timbrado
    """,
    'description': """
        Módulo para extender la funcionalidad de contabilidad
    """,
    'author': "Merida Soft",
    'website': "http://www.meridasoft.com/",
    'category': 'Account',
    'version': '0.1',
    'depends': [
        'base', 'l10n_mx', 'account',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/cron.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}

