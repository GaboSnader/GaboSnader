# -*- coding:utf-8 -*-

from . import accounting_assistant
from . import wizard_accounting_assistant
