# -*- coding: utf-8 -*-
from . import res_users
from . import equipo
from . import departamento
from . import area
from . import tipo_operacion
from . import negocio
from . import purchase_order
from . import purchase_order_line
from . import account_move
from . import account_move_line
from . import account_payment
from . import hr_employee
from . import account_asset
