# -*- coding: utf-8 -*-

{
    'name' : 'Triple Autorizacion de Pedido de Compras',
    'author': 'Gabriel Lopez Alarcon',
    'version' : '1',
    'summary': '',
    'sequence': 30,
    'description': """


    """,
    'category': '',
    'website': '',
    'images' : [],
    'depends' : ['purchase', 'base'],
    'data': [
        'val_purchase.xml',
           ],
    'demo': [

    ],
    'qweb': [

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
