# -*- coding: utf-8 -*-

import val_purchase