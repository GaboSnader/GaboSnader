# -*- coding: utf-8 -*-
import logging
import datetime
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class PTUEmpleado(models.Model):
    _name = 'ptu.employee'

    code = fields.Char(string=u"Código", default="PTU")
    year = fields.Char(string=u"Año", required=True)
    amount = fields.Float(string="Monto", required=True)
    employee_id = fields.Many2one('hr.employee', string='Empleado')
    name = fields.Char(string="PTU", compute="_compute_name")

    @api.constrains('year')
    def _constrains_year(self):
        for rec in self:
            try:
                if rec.year:
                    year = int(rec.year)
                    if year > 9999 or year < 999:
                        raise ValidationError("El formato de año es incorrecto")
            except:
                raise ValidationError("El formato de año es incorrecto")

    def _compute_name(self):
        for record in self:
            record.name = "%s %s" % (record.code, str(record.year))


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    ptu_list = fields.One2many('ptu.employee', 'employee_id', string="Listado PTU")
    has_ptu = fields.Boolean(string="Corresponde PTU", default=True)

class HrPayslipEmployees(models.TransientModel):
    _inherit = 'hr.payslip.employees'

    def compute_sheet(self):
        res = super(HrPayslipEmployees, self).compute_sheet()
        type_ids = self.env['hr.work.entry.type'].search([('code','=','PTU')])
        for entry in type_ids:
            work_entry_type_id = entry
        if self.env.context.get('active_id'):
            payslip_run = self.env['hr.payslip.run'].browse(self.env.context.get('active_id'))
            if payslip_run.is_ptu:
                year = int(payslip_run.fecha_pago.strftime("%Y"))
                days_emp = 0.0
                salary = 0.0
                amount = payslip_run.ptu_amount/2
                for emp in self.employee_ids:
                    if emp.dias_utilidad >= 60:
                        days_emp += emp.dias_utilidad
                        salary += emp.sueldo_utilidad
                if days_emp == 0 or salary == 0:
                    raise ValidationError("No existe configuracion de utilidades para empleados.")
                factor_day = amount/days_emp
                factor_salary = amount/salary
                for slip in payslip_run.slip_ids:
                    balance_condition = False
                    if slip.employee_id.dias_utilidad >= 60:
                        balance_condition = self._get_balance_condition(slip.employee_id, year, slip.contract_id)
                        total_days = slip.employee_id.dias_utilidad*factor_day
                        total_salary = slip.employee_id.sueldo_utilidad*factor_day
                        total = total_salary + total_days
                        if total > balance_condition:
                            total = balance_condition
                        vals = {
                                'work_entry_type_id': work_entry_type_id.id,
                                'name': 'Utilidades',
                                'number_of_days': slip.employee_id.dias_utilidad,
                                'amount': total,
                                'payslip_id': slip.id,
                                }
                        worked_days_id = self.env['hr.payslip.worked_days'].create(vals)
                        worked_days_id.amount = total
        return res

    def _get_balance_condition(self, employee, year, contract):
        age_balance = 0.0
        if not employee.ptu_list:
            raise ValidationError("No existe la configuracion para el calculo de las utilidades del empleado %s" %(employee.name))
        for ptu in employee.ptu_list:
            if (year-1) == ptu.year:
                age_balance += ptu.amount
            elif (year-2) == ptu.year:
                age_balance += ptu.amount
            elif (year-3) == ptu.year:
                age_balance += ptu.amount
        contract_balance = float(contract.wage)*3
        age_balance = age_balance/3
        if age_balance > contract_balance:
            return age_balance
        else:
            return contract_balance

