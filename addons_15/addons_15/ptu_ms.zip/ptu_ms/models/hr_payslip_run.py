# -*- coding: utf-8 -*-
import logging
from odoo import api, models, fields, _

_logger = logging.getLogger(__name__)


class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    is_ptu = fields.Boolean('Pago PTU')
    ptu_amount = fields.Float(string="Monto a repartir")
    ptu_percentage = fields.Integer(string="Porciento total utilidad")

    tipo_nomina = fields.Selection(
        selection=[('O', 'Nómina ordinaria'), 
                   ('E', 'Nómina extraordinaria'),
                   ('PTU', 'Nómina ptu'),
                   ('A', 'Aguinaldo'),
                   ('FIN', 'Finiquito/Indemnizacion'),],
        string=_('Tipo de nómina'), required=True, default='O'
    )