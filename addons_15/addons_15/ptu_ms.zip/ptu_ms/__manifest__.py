# -*- coding: utf-8 -*-
{
    'name': 'PTU para Mexico',
    'version': '1.0',
    'description': 'Modulo para la repartición de PTU de Empleados',
    'author': 'Meridasoft',
    'license': 'LGPL-3',
    'category': 'Nómina',
    'depends': [
        'hr_payroll',
        'hr_contract',
        'nomina_ms',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/ptu_data.xml',
        'views/hr_employee_view.xml',
        'views/hr_payslip_run_view.xml',
    ],
    # 'auto_install': True,
    'application': False,
    'installable': True,
} 
