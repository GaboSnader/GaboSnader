# -*- coding: utf-8 -*-

from . import product_template
from . import stock_location
