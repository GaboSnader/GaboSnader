# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

from odoo.addons.website_sale.controllers.variant import WebsiteSaleVariantController

class ProductLocationWebsiteSaleVariantController(WebsiteSaleVariantController):
    @http.route(['/sale/get_combination_info_website'], type='json', auth="public", methods=['POST'], website=True)
    def get_combination_info_website(self, product_template_id, product_id, combination, add_qty, **kw):
        #print("ENTRA EN LA HERENCIA")
        kw.pop('pricelist_id')
        res = self.get_combination_info(product_template_id, product_id, combination, add_qty, request.website.get_current_pricelist(), **kw)

        product = request.env['product.template'].browse(res['product_template_id'])
        product['location_url'] = "https://maps.google.com/maps?width=100&height=600&hl=en&q=%s,%s+(%s)&t=&z=14&ie=UTF8&iwloc=B&output=embed" % (product.altitude, product.longitude, product.title)
        print("MODIFICACION=========")
        carousel_view = request.env['ir.ui.view']._render_template('product_location.shop_product_carousel',
            values={
                'product': product,
                'product_variant': request.env['product.product'].browse(res['product_id']),
            })
        res['carousel'] = carousel_view
        return res
