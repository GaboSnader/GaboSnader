# -*- coding: utf-8 -*-
from odoo import fields, models

class ProductTemplate(models.Model):
    _inherit = "product.template"

    title = fields.Char(string='Titulo del lote', required=True)
    altitude = fields.Float(string='Altitud', required=True, digits=(13,13))
    longitude = fields.Float(string='Logitud', required=True, digits=(13,13))
    location_url = fields.Char(string='URl',)