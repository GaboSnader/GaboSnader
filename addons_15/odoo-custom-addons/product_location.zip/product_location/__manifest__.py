# -*- coding: utf-8 -*-
{
    'name': 'product_location',
    'version': '1.0',
    'description': 'Se añaden caracteristicas para Comercio electrónico',
    'summary': 'Se añaden caracteristicas para Comercio electrónico',
    'author': 'Seidor',
    'license': 'LGPL-3',
    'category': 'website_sale',
    'depends': [
        'base',
        'website_sale',
    ],
    'data': [
        'views/product_location_view.xml',
        'views/product_template_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
