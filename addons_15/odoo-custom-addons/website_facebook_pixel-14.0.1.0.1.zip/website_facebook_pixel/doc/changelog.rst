.. _changelog:

Changelog
=========

`14.0.1.0.1`
------------

- Price set as free.

`14.0.1.0.0`
------------

- Migration to 14.0


