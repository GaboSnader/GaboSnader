from . import res_company
from . import hr_employee
from . import hr_contract
from . import res_partner
from . import account_move_line
from . import account_payment