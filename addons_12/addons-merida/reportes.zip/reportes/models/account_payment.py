# -*- coding: utf-8 -*-
from odoo import models, fields, api


class AccountPayment(models.Model):
    _inherit = "account.payment"

    def _get_invoice(self,inv):
        name=self.move_name
        name_payment = self.name
        company_id=self.company_id.id
        # print(name)

        self._cr.execute("""
                       select ml.id,m.date as date,
                        m.name as accounting_entries,
                        concat(cj.name,'(',c.name,')') as journal,
                        ml.name as tag,m.ref as reference,
                        rp.name as partner,concat(acc.code,' ',acc.name) as account, 
                        case 
                        when (select name from res_partner where id=ac.partner_id) is null then
                        ac.name 
                        else concat(ac.name,'-',(select name from res_partner where id=ac.partner_id))
                        END as analytic_account,
                        array_to_string( array_agg(distinct aat.name),',') as analytic_tag,
                        fr.name as full_reconcile, ml.debit as debit,ml.credit as credit,
                        ml.amount_currency as amount_currency,
                        ml.date_maturity as date_maturity
                        from  account_move_line  ml 
                        inner join account_move m on m.id=ml.move_id
                        left join res_currency c on c.id=ml.company_currency_id
                        left join account_journal cj on cj.id=ml.journal_id  
                        left join res_partner rp on rp.id=m.partner_id
                        left join account_account acc on acc.id=ml.account_id 
                        left join account_full_reconcile fr on fr.id=ml.full_reconcile_id
                        left join account_analytic_account ac on ac.id=ml.analytic_account_id
                        left join account_analytic_tag_account_move_line_rel x on ml.id=x.account_move_line_id
                        left join account_analytic_tag aat on aat.id=x.account_analytic_tag_id
                        where m.company_id='%s' and (m.name='%s' or m.ref='%s' )
                        group by ml.id,m.date,m.name,cj.name,c.name,m.ref,rp.name,acc.code,acc.name,ac.name,
                        fr.name,m.partner_id,ac.partner_id
                        order by ml.id asc

                       """ % (company_id,name,name))

        lines_poliza = self.env.cr.dictfetchall()
        # print(lines_poliza)

        return lines_poliza


    def _sum_account(self,inv):
        name = self.move_name
        name_payment=self.name
        company_id=self.company_id.id
        # print(name)
        #print(name_payment)

        self._cr.execute("""      
                    select sum(ml.debit) as total_debit,sum(ml.credit) as total_credit
                    from  account_move_line  ml 
                    inner join account_move  m on m.id=ml.move_id
                    where m.company_id='%s' and (m.name='%s' or m.ref='%s')
                              """ % (company_id,name,name))

        sum = self.env.cr.dictfetchall()
        # print(sum)

        return sum





