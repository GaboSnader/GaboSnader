# -*- coding: utf-8 -*-
import base64
import logging
import zipfile
from io import BytesIO
from tempfile import NamedTemporaryFile
from openpyxl import Workbook
from openpyxl.styles import PatternFill
from odoo import models, fields, api
from odoo.exceptions import ValidationError
_logger = logging.getLogger(__name__)

class ReporteCierreLoteByLot(models.TransientModel):
    _name = 'auxiliar.contable.report.download'

    # def default_account_lines(self):
    #     lines = []
    #     context = dict(self._context or {})
    #     account_ids = self.env['account.move.line'].browse(context.get('records'))
    #     print(account_ids)
    #     for account in account_ids:
    #         lines.append(account.id)
    #     return lines

    xlsx_attach = fields.Binary(string='in Excel')
    pdf_attach = fields.Binary(string='in PDF')
    # account_line_ids = fields.Many2many(
    #     'account.move.line', string='Líneas', default=default_account_lines)

    def get_auxiliar_pdf(self):
        context = dict(self._context or {})
        move_ids = self.env['account.move.line'].browse(context.get('records'))
        return self.generate_pdf(move_ids)

    def get_auxiliar_pdf_se(self):
        context = dict(self._context or {})
        move_ids = self.env['account.move.line'].browse(context.get('records'))
        
        data = {
            'data': self.generate_data(move_ids)
        }
        return self.env.ref('reportes.auxiliar_contable_report_action_sc').report_action(self, data=data,config=False)
            
    def get_auxiliar_xlsx(self):
        context = dict(self._context or {})
        move_ids = self.env['account.move.line'].browse(context.get('records'))
        return self.generate_xlsx(move_ids)

    def generate_pdf(self, moves):
        data = {
            'data': self.generate_data(moves)
        }
        print('VAMOS AQUI')
        return self.env.ref('reportes.auxiliar_contable_report_action').report_action(self, data=data,config=False)
        
    def generate_xlsx(self, moves):
        headers = self._get_header()
        details = self.generate_data(moves)
        filename = 'Auxiliar_contable.xlsx' 
        output = self._create_xlsx(
            Workbook, NamedTemporaryFile, headers=headers, body=details)
        xlsx = {
            'name': filename,
            'datas_fname': filename,
            'type': 'binary',
            'res_model': self._name,
            'datas': base64.b64encode(output),
            'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        }
        inserted_id = self.env['ir.attachment'].create(xlsx)
        url = '/web/content/%s?download=1' % (inserted_id.id)
        return {
            'type': 'ir.actions.act_url',
            'name': filename,
            'url': url
        }

    def generate_data(self, movimientos):
        res = []
        for c in movimientos:
            res.append({
                'date': c.date,
                'move_id': c.move_id.name,
                'journal_id': c.journal_id.name,
                'name': c.name,
                'ref': c.ref,
                'partner_id': c.partner_id.name,
                'account_id': c.account_id.name,
                'saldo_inicial': c.saldo_inicial,
                'debit': c.debit,
                'credit': c.credit,
                'saldo_final': c.saldo_final,
                'date_maturity': c.date_maturity,
            })
        return res
    
    def _create_xlsx(self, Workbook, NamedTemporaryFile,headers=None, body=None):
        wb = Workbook()
        ws = wb.active
        self._create_header(ws, headers)
        self._create_body(ws, body)
        output = None
        with NamedTemporaryFile() as tmp:
            for column_cells in ws.columns:
                length = max(len(self.as_text(cell.value)) for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = length
            #self.add_color(ws)
            wb.save(tmp.name)
            output = tmp.read()
        return output

    def _create_header(self, ws, headers):
        index = 1
        for header in headers:
            ws.cell(row=1, column=index, value=header)
            index += 1
        return ws
    
    def _create_body(self, ws, regs):
        index = 2
        for reg in regs:
            self._create_row(ws, index, reg)
            index += 1
        return ws

    def _create_row(self, ws, index, reg):
        ws.cell(row=index,
            column=1,
            value=reg['date'])
        ws.cell(row=index,
            column=2,
            value=reg['move_id'])
        ws.cell(row=index,
            column=3,
            value=reg['journal_id'])
        ws.cell(row=index,
            column=4,
            value=reg['name'])
        ws.cell(row=index,
            column=5,
            value=reg['ref'])
        ws.cell(row=index,
            column=6,
            value=reg['partner_id'])
        ws.cell(row=index,
            column=7,
            value=reg['account_id'])
        ws.cell(row=index,
            column=8,
            value=reg['saldo_inicial'])
        ws.cell(row=index,
            column=9,
            value=reg['debit'])
        ws.cell(row=index,
            column=10,
            value=reg['credit'])
        ws.cell(row=index,
            column=11,
            value=reg['saldo_final'])
        ws.cell(row=index,
            column=12,
            value=reg['date_maturity'])
        return ws

    def _get_header(self):
        return [
            'Fecha',
            'Asiento contable',
            'Diario',
            'Etiqueta',
            'Referencia',
            'Empresa',
            'Cuenta',
            'Saldo-inicial',
            'Debe',
            'Haber',
            'Saldo-final',
            'Fecha vencimiento',
        ]

    def as_text(self,value):
        if value is None:
            return ""
        return str(value)
