#-*- coding: utf-8 -*-
{
    'name': "Reportes",
    'summary': """
        Módulo complementario de Agrovizion para reportes
    """,
    'description': """
        Módulo para extender la funcionalidad de empleados
    """,
    'author': "Gabriel Lopez",
    'website': "",
    'category': 'hr',
    'version': '0.1',
    'depends': [
        'account', 'account_accountant', 'hr', 'base', 'l10n_mx_edi', 'hr_attendance', 'hr_contract', 'hr_payroll',
    ],
    'data': [
        'views/res_company_views.xml',
        'views/hr_employee.xml',
        'views/hr_contract.xml',
        'reports/contrato_confidencialidad_templates.xml',
        'reports/contrato_indeterminado_antiguedad.xml',
        'reports/adhesion_sindicato_templates.xml',
        'reports/aviso_privacidad_templates.xml',
        'reports/asistencia_electronica.xml',
        'reports/conflicto_de_intereses_templates.xml',
        'reports/recibo_nomina_templates.xml',
        'reports/finiquito_templates.xml',
        'reports/entrevista_salida_templates.xml',
        'reports/contrato_indeterminado_templates.xml',
        'reports/contrato_determinado_templates.xml',
        'reports/solicitud_baja_templates.xml',
        'reports/renuncia_templates.xml',
        'reports/transferencia_templates.xml',
        'reports/account_invoice_report.xml',
        'reports/auxiliar_contable_report.xml',
        'reports/report_payment_policy.xml',
        'wizard/auxiliar_contable_report_download.xml',
        'reports/reports.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}

